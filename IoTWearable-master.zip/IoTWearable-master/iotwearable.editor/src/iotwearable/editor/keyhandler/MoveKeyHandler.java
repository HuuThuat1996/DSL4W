package iotwearable.editor.keyhandler;


public abstract class MoveKeyHandler implements IMoveKeyHandler{
	
	public MoveKeyHandler() {
	}
}