package iotwearable.editor.figure;

import org.eclipse.draw2d.XYLayout;

public class ConnectivityFigure extends  DeviceFigure{
	public ConnectivityFigure() {
		setLayoutManager(new XYLayout());
	}
}
