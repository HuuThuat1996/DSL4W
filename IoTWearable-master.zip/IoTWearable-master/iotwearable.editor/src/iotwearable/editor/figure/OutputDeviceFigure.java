package iotwearable.editor.figure;
/**
 *Abstract class for all output controls figure 
 */
public abstract class OutputDeviceFigure extends IODeviceFigure{
	public OutputDeviceFigure() {
		super();
	}
}
