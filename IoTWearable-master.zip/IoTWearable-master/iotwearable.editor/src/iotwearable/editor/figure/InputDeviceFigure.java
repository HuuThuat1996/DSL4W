package iotwearable.editor.figure;
/**
 * Abstract class for all input controls figure
 */
public abstract class InputDeviceFigure extends IODeviceFigure{
	public InputDeviceFigure() {
		super();
	}
}
