# IoT Wearable
## Giới thiệu
Xây dựng công cụ hỗ trợ tạo mã cho ứng dụng chạy trên thiết bị wearable.
## Tham khảo
1, https://www.eclipse.org/articles/Article-GEF-editor/gef-schema-editor.html

2, https://www.vainolo.com/tutorials/gef-tutorials/

3, https://wiki.eclipse.org/GEF_Description#EditPartViewer.2C_RootEditPart

4, http://www.eclipse.org/articles/Article-GEF-diagram-editor/shape.html

5, https://www.programcreek.com/java-api-examples/index.php?api=org.eclipse.draw2d.IFigure

6, https://help.eclipse.org/mars/index.jsp?topic=%2Forg.eclipse.draw2d.doc.isv%2Freference%2Fapi%2Forg%2Feclipse%2Fdraw2d%2FIFigure.html

7, https://help.eclipse.org/neon/index.jsp?topic=%2Forg.eclipse.gef.doc.isv%2Freference%2Fapi%2Forg%2Feclipse%2Fgef%2Fui%2Fparts%2FGraphicalEditor.html

8, http://download.eclipse.org/modeling/emf/emf/javadoc/2.9.0/org/eclipse/emf/ecore/package-summary.html#details

9, http://www.philmann-dark.de/EMFDocs/tutorial.html
