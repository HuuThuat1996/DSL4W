package iotwearable.gen.utilities;

@SuppressWarnings("serial")
public class GenRuntimeException extends RuntimeException{
	public GenRuntimeException(String msg) {
		super(msg);
	}
}