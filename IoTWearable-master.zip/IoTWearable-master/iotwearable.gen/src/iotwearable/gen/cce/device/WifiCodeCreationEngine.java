package iotwearable.gen.cce.device;

public abstract class WifiCodeCreationEngine extends DeviceCodeCreationEngine{
	
	@Override
	public String createPrototype() {
		return "bool waitforACK(char ackstring[], int timeout);\n"
				+ "void sendToWifi(String request);";
	}
	@Override
	public String createInclude() {
		return "#include <"+DeviceLibrary.SoftwareSerial+".h>";
	}
	@Override
	public String createInitSetup() {
		return "Serial.begin(9600);\n"
				+"<id>.begin(9600); // Change baud rate according to your ESP\n"
				+"<id>.println(\"AT+CWMODE=3\");\n"
				+ "delay(10);\n"
				+ "<id>.println(\"AT+RST\");\n"
				+ "if(!waitforACK(\"OK\", 10000)) {\n"
				+ "Serial.println(\"Cannot reset\");"
				+ "\n}\n"
				+ "else  {\n"
				+ "Serial.println(\"Reset OK\");"
				+ "\n}";
	}
	
	@Override
	public String createDefine() {
		String content = "/*Define <type> - <id> */\n";
		content +="SoftwareSerial <id>(<pinRX>, <pinTX>);\n"
				+ "boolean <id>_Ret = true;";
		return content;
	}
}