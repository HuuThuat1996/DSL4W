package iotwearable.gen.cce.device;

import java.util.LinkedList;

import iotwearable.gen.comanalyzer.Token;
import iotwearable.model.iotw.I2CLCD2004;

public class I2CLCD2004CodeCreationEngine extends I2CLCDCodeCreationEngine{
	private I2CLCD2004  i2clcd2004;
	
	public I2CLCD2004CodeCreationEngine(I2CLCD2004  i2clcd2004) {
		super();
		this.i2clcd2004 = i2clcd2004;
	}
	@Override
	public String createDefine() {
		return super.createDefine()
				.replaceAll("<id>", i2clcd2004.getId())
				.replaceAll("<width>", "20")
				.replaceAll("<height>", "4");
	}
	@Override
	public String createInitSetup() {
		return super.createInitSetup()
				.replaceAll("<id>", i2clcd2004.getId())
				.replaceAll("<cols>", "20")
				.replaceAll("<rows>", "4");
	}
	@Override
	public String createInitLoop() {
		return "";
	}
	@Override
	public String createFromCommand(String syntax, LinkedList<Token> tokens) {
		String command = super.createFromCommand(syntax, tokens);
		if(command.contains("<id>")){
			command = command.replaceAll("<id>", i2clcd2004.getId());
		}
		return command;
	}
	@Override
	public String createPrototype() {
		return "";
	}
	@Override
	public String createMethodImpl() {
		return "";
	}
}