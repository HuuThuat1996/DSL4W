package iotwearable.gen.cce.device;

import java.util.LinkedList;

import iotwearable.gen.comanalyzer.Token;
import iotwearable.model.iotw.WifiESP8266;
import iotwearable.model.iotw.WifiMode;

public class WifiESP8266CodeCreationEngine extends WifiCodeCreationEngine {
	private WifiESP8266 wifiESP8266;
	
	public WifiESP8266CodeCreationEngine(WifiESP8266 wifiESP8266) {
		this.wifiESP8266= wifiESP8266;
	}

	@Override
	public String createInitSetup() {
		String result = super.createInitSetup()
				.replaceAll("<id>", wifiESP8266.getId());
		if(wifiESP8266.getMode().equals(WifiMode.ACCESS_POINT)){
			result += "\n" + createSetupAP();
		}
		else if(wifiESP8266.getMode().equals(WifiMode.STATION)){
			result += "\n" + createSetupST();
		}
		else if(wifiESP8266.getMode().equals(WifiMode.BOTH)){
			result += "\n" + createSetupAP();
			result += "\n" + createSetupST();
		}
		return result;
	}
	private String createSetupAP(){
		String result = wifiESP8266.getId()+".println("+"\""
				+ "AT+CWJAP="+"\\\""+wifiESP8266.getSSID_AP()+"\\\""+","
						+ "\\\""+wifiESP8266.getPassword_AP()+"\\\""+"\""+");\n"
								+ "if(!waitforACK(\"OK\", 10000)){\n"
								+ "Serial.println(\"Cannot connect to AP\");"
								+ "\n}\n"
								+ "else{\n"
								+ "Serial.println(\"Connect to AP\");"
								+ "\n}\n"
								+ wifiESP8266.getId() + ".println("+"\""
								+"AT+CIPSTART=\\\"TCP\\\""
								+"," +"\\\""+wifiESP8266.getHost()+"\\\""+","+wifiESP8266.getPort()+"\""+");\n"
								+ wifiESP8266.getId()+"_Ret = waitforACK(\"Linked\", 5000);\n"
								+ "if(!"+wifiESP8266.getId()+"_Ret"+"){\n"
								+ "Serial.println(\"Cannot connect to Server\");"
								+ "\n}\n"
								+ "else{\n"
								+ "Serial.println(\"Linked to Server\");"
								+ "\n}";
		return result;
	}
	private String createSetupST(){
		return "";
	}
	@Override
	public String createDefine() {
		String content = super.createDefine();
		content = content.replaceAll("<pinTX>", wifiESP8266.getMainboard().findPin(wifiESP8266.getPinTX()).getName())
				.replaceAll("<pinRX>", wifiESP8266.getMainboard().findPin(wifiESP8266.getPinRX()).getName())
				.replaceAll("<id>", wifiESP8266.getId())
				.replaceAll("<type>", wifiESP8266.getName());
		return content;
	}

	@Override
	public String createInitLoop() {
		return "";
	}
	@Override
	public String createFromCommand(String syntax, LinkedList<Token> tokens) {
		return "";
	}

	@Override
	public String createMethodImpl() {
		return "bool waitforACK(char ackstring[], int timeout){\n"
				  +"unsigned long start = millis();"
				  +"while(millis() < start+timeout) {\n"
				   + "if("+wifiESP8266.getId()+".available()){\n" 
				    +  "if("+wifiESP8266.getId()+".find(ackstring))\n"
				     +   "return true;\n"
				    +"\n}\n"
				  +"\n}\n"
				  +"return false;"
				+"\n}"
				+ "\n//Send to wifi\n"
				+"void sendToWifi(char* request){\n"
				+"int leg = strlen(request);\n"
				+""+wifiESP8266.getId()+".println(\"AT+CIPSEND="+wifiESP8266.getIdConnection().getValue()+",\"+leg);\n"
				 + "if(!waitforACK(\">\", 5000))"
				  +"\n{\n"
				   +"Serial.println(\"Cannot setup sending data\");"
				  +"\n}\n"
				  +"else"
				  +"{\n"
				   +"Serial.println(\"Sending data\");\n"
				    +""+wifiESP8266.getId()+".println(request);"
				  +"\n}\n"
				   +"if(!waitforACK(\"SEND OK\", 5000))"
				  +"{\n"
				   +"Serial.println(\"SEND DATA FAILED\");"
				+"\n}\n"
				 +"else"
				  +"{\n"
				   +"Serial.println(\"Sending data OK\");"
				  +"\n}\n"
				+"\n}\n";
	}
}