package iotwearable.gen.comanalyzer;

public enum Grammar {
	V,
	V_A_N,	// verb + art + noun
	V_N,	//verb + noun
}