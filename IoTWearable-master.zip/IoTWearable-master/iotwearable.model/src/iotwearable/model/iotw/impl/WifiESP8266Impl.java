/**
 */
package iotwearable.model.iotw.impl;

import iotwearable.model.iotw.IotwFactory;
import iotwearable.model.iotw.IotwPackage;
import iotwearable.model.iotw.Pin;
import iotwearable.model.iotw.WifiESP8266;

import iotwearable.model.iotw.WifiIDConnection;
import iotwearable.model.iotw.WifiMode;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Wifi ESP8266</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPinTX <em>Pin TX</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPinRX <em>Pin RX</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPinVcc <em>Pin Vcc</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPinGND <em>Pin GND</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPinCHPD <em>Pin CHPD</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getSSID_ST <em>SSID ST</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPassword_ST <em>Password ST</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getSSID_AP <em>SSID AP</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPassword_AP <em>Password AP</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getHost <em>Host</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getPort <em>Port</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getMode <em>Mode</em>}</li>
 *   <li>{@link iotwearable.model.iotw.impl.WifiESP8266Impl#getIdConnection <em>Id Connection</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class WifiESP8266Impl extends ConnectivityImpl implements WifiESP8266 {
	/**
	 * The default value of the '{@link #getPinTX() <em>Pin TX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinTX()
	 * @generated
	 * @ordered
	 */
	protected static final Pin PIN_TX_EDEFAULT = (Pin)IotwFactory.eINSTANCE.createFromString(IotwPackage.eINSTANCE.getPin(), "TX,IO");

	/**
	 * The cached value of the '{@link #getPinTX() <em>Pin TX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinTX()
	 * @generated
	 * @ordered
	 */
	protected Pin pinTX = PIN_TX_EDEFAULT;

	/**
	 * The default value of the '{@link #getPinRX() <em>Pin RX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinRX()
	 * @generated
	 * @ordered
	 */
	protected static final Pin PIN_RX_EDEFAULT = (Pin)IotwFactory.eINSTANCE.createFromString(IotwPackage.eINSTANCE.getPin(), "RX,IO");

	/**
	 * The cached value of the '{@link #getPinRX() <em>Pin RX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinRX()
	 * @generated
	 * @ordered
	 */
	protected Pin pinRX = PIN_RX_EDEFAULT;

	/**
	 * The default value of the '{@link #getPinVcc() <em>Pin Vcc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinVcc()
	 * @generated
	 * @ordered
	 */
	protected static final Pin PIN_VCC_EDEFAULT = (Pin)IotwFactory.eINSTANCE.createFromString(IotwPackage.eINSTANCE.getPin(), "Vcc,Power");

	/**
	 * The cached value of the '{@link #getPinVcc() <em>Pin Vcc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinVcc()
	 * @generated
	 * @ordered
	 */
	protected Pin pinVcc = PIN_VCC_EDEFAULT;

	/**
	 * The default value of the '{@link #getPinGND() <em>Pin GND</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinGND()
	 * @generated
	 * @ordered
	 */
	protected static final Pin PIN_GND_EDEFAULT = (Pin)IotwFactory.eINSTANCE.createFromString(IotwPackage.eINSTANCE.getPin(), "GND,Power");

	/**
	 * The cached value of the '{@link #getPinGND() <em>Pin GND</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinGND()
	 * @generated
	 * @ordered
	 */
	protected Pin pinGND = PIN_GND_EDEFAULT;

	/**
	 * The default value of the '{@link #getPinCHPD() <em>Pin CHPD</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinCHPD()
	 * @generated
	 * @ordered
	 */
	protected static final Pin PIN_CHPD_EDEFAULT = (Pin)IotwFactory.eINSTANCE.createFromString(IotwPackage.eINSTANCE.getPin(), "CHPD,Power");

	/**
	 * The cached value of the '{@link #getPinCHPD() <em>Pin CHPD</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinCHPD()
	 * @generated
	 * @ordered
	 */
	protected Pin pinCHPD = PIN_CHPD_EDEFAULT;

	/**
	 * The default value of the '{@link #getSSID_ST() <em>SSID ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSSID_ST()
	 * @generated
	 * @ordered
	 */
	protected static final String SSID_ST_EDEFAULT = "IotWearable";

	/**
	 * The cached value of the '{@link #getSSID_ST() <em>SSID ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSSID_ST()
	 * @generated
	 * @ordered
	 */
	protected String sSID_ST = SSID_ST_EDEFAULT;

	/**
	 * The default value of the '{@link #getPassword_ST() <em>Password ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword_ST()
	 * @generated
	 * @ordered
	 */
	protected static final String PASSWORD_ST_EDEFAULT = "IotWearable";

	/**
	 * The cached value of the '{@link #getPassword_ST() <em>Password ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword_ST()
	 * @generated
	 * @ordered
	 */
	protected String password_ST = PASSWORD_ST_EDEFAULT;

	/**
	 * The default value of the '{@link #getSSID_AP() <em>SSID AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSSID_AP()
	 * @generated
	 * @ordered
	 */
	protected static final String SSID_AP_EDEFAULT = "IotWearable";

	/**
	 * The cached value of the '{@link #getSSID_AP() <em>SSID AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSSID_AP()
	 * @generated
	 * @ordered
	 */
	protected String sSID_AP = SSID_AP_EDEFAULT;

	/**
	 * The default value of the '{@link #getPassword_AP() <em>Password AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword_AP()
	 * @generated
	 * @ordered
	 */
	protected static final String PASSWORD_AP_EDEFAULT = "IotWearable";

	/**
	 * The cached value of the '{@link #getPassword_AP() <em>Password AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword_AP()
	 * @generated
	 * @ordered
	 */
	protected String password_AP = PASSWORD_AP_EDEFAULT;

	/**
	 * The default value of the '{@link #getHost() <em>Host</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHost()
	 * @generated
	 * @ordered
	 */
	protected static final String HOST_EDEFAULT = "192.168.200.46";

	/**
	 * The cached value of the '{@link #getHost() <em>Host</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHost()
	 * @generated
	 * @ordered
	 */
	protected String host = HOST_EDEFAULT;

	/**
	 * The default value of the '{@link #getPort() <em>Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected static final int PORT_EDEFAULT = 8080;

	/**
	 * The cached value of the '{@link #getPort() <em>Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected int port = PORT_EDEFAULT;

	/**
	 * The default value of the '{@link #getMode() <em>Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMode()
	 * @generated
	 * @ordered
	 */
	protected static final WifiMode MODE_EDEFAULT = WifiMode.BOTH;

	/**
	 * The cached value of the '{@link #getMode() <em>Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMode()
	 * @generated
	 * @ordered
	 */
	protected WifiMode mode = MODE_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdConnection() <em>Id Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdConnection()
	 * @generated
	 * @ordered
	 */
	protected static final WifiIDConnection ID_CONNECTION_EDEFAULT = WifiIDConnection.ID_0;

	/**
	 * The cached value of the '{@link #getIdConnection() <em>Id Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdConnection()
	 * @generated
	 * @ordered
	 */
	protected WifiIDConnection idConnection = ID_CONNECTION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected WifiESP8266Impl() {
		super();
		this.name ="Wifi ESP8266";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotwPackage.Literals.WIFI_ESP8266;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pin getPinTX() {
		return pinTX;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPinTX(Pin newPinTX) {
		Pin oldPinTX = pinTX;
		pinTX = newPinTX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PIN_TX, oldPinTX, pinTX));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pin getPinRX() {
		return pinRX;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPinRX(Pin newPinRX) {
		Pin oldPinRX = pinRX;
		pinRX = newPinRX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PIN_RX, oldPinRX, pinRX));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pin getPinVcc() {
		return pinVcc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPinVcc(Pin newPinVcc) {
		Pin oldPinVcc = pinVcc;
		pinVcc = newPinVcc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PIN_VCC, oldPinVcc, pinVcc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pin getPinGND() {
		return pinGND;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPinGND(Pin newPinGND) {
		Pin oldPinGND = pinGND;
		pinGND = newPinGND;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PIN_GND, oldPinGND, pinGND));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pin getPinCHPD() {
		return pinCHPD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPinCHPD(Pin newPinCHPD) {
		Pin oldPinCHPD = pinCHPD;
		pinCHPD = newPinCHPD;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PIN_CHPD, oldPinCHPD, pinCHPD));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSSID_ST() {
		return sSID_ST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSSID_ST(String newSSID_ST) {
		String oldSSID_ST = sSID_ST;
		sSID_ST = newSSID_ST;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__SSID_ST, oldSSID_ST, sSID_ST));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPassword_ST() {
		return password_ST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPassword_ST(String newPassword_ST) {
		String oldPassword_ST = password_ST;
		password_ST = newPassword_ST;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PASSWORD_ST, oldPassword_ST, password_ST));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSSID_AP() {
		return sSID_AP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSSID_AP(String newSSID_AP) {
		String oldSSID_AP = sSID_AP;
		sSID_AP = newSSID_AP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__SSID_AP, oldSSID_AP, sSID_AP));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPassword_AP() {
		return password_AP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPassword_AP(String newPassword_AP) {
		String oldPassword_AP = password_AP;
		password_AP = newPassword_AP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PASSWORD_AP, oldPassword_AP, password_AP));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHost() {
		return host;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHost(String newHost) {
		String oldHost = host;
		host = newHost;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__HOST, oldHost, host));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPort() {
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPort(int newPort) {
		int oldPort = port;
		port = newPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__PORT, oldPort, port));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WifiMode getMode() {
		return mode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMode(WifiMode newMode) {
		WifiMode oldMode = mode;
		mode = newMode == null ? MODE_EDEFAULT : newMode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__MODE, oldMode, mode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WifiIDConnection getIdConnection() {
		return idConnection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIdConnection(WifiIDConnection newIdConnection) {
		WifiIDConnection oldIdConnection = idConnection;
		idConnection = newIdConnection == null ? ID_CONNECTION_EDEFAULT : newIdConnection;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotwPackage.WIFI_ESP8266__ID_CONNECTION, oldIdConnection, idConnection));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IotwPackage.WIFI_ESP8266__PIN_TX:
				return getPinTX();
			case IotwPackage.WIFI_ESP8266__PIN_RX:
				return getPinRX();
			case IotwPackage.WIFI_ESP8266__PIN_VCC:
				return getPinVcc();
			case IotwPackage.WIFI_ESP8266__PIN_GND:
				return getPinGND();
			case IotwPackage.WIFI_ESP8266__PIN_CHPD:
				return getPinCHPD();
			case IotwPackage.WIFI_ESP8266__SSID_ST:
				return getSSID_ST();
			case IotwPackage.WIFI_ESP8266__PASSWORD_ST:
				return getPassword_ST();
			case IotwPackage.WIFI_ESP8266__SSID_AP:
				return getSSID_AP();
			case IotwPackage.WIFI_ESP8266__PASSWORD_AP:
				return getPassword_AP();
			case IotwPackage.WIFI_ESP8266__HOST:
				return getHost();
			case IotwPackage.WIFI_ESP8266__PORT:
				return getPort();
			case IotwPackage.WIFI_ESP8266__MODE:
				return getMode();
			case IotwPackage.WIFI_ESP8266__ID_CONNECTION:
				return getIdConnection();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IotwPackage.WIFI_ESP8266__PIN_TX:
				setPinTX((Pin)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_RX:
				setPinRX((Pin)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_VCC:
				setPinVcc((Pin)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_GND:
				setPinGND((Pin)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_CHPD:
				setPinCHPD((Pin)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__SSID_ST:
				setSSID_ST((String)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PASSWORD_ST:
				setPassword_ST((String)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__SSID_AP:
				setSSID_AP((String)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PASSWORD_AP:
				setPassword_AP((String)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__HOST:
				setHost((String)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__PORT:
				setPort((Integer)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__MODE:
				setMode((WifiMode)newValue);
				return;
			case IotwPackage.WIFI_ESP8266__ID_CONNECTION:
				setIdConnection((WifiIDConnection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case IotwPackage.WIFI_ESP8266__PIN_TX:
				setPinTX(PIN_TX_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_RX:
				setPinRX(PIN_RX_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_VCC:
				setPinVcc(PIN_VCC_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_GND:
				setPinGND(PIN_GND_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PIN_CHPD:
				setPinCHPD(PIN_CHPD_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__SSID_ST:
				setSSID_ST(SSID_ST_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PASSWORD_ST:
				setPassword_ST(PASSWORD_ST_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__SSID_AP:
				setSSID_AP(SSID_AP_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PASSWORD_AP:
				setPassword_AP(PASSWORD_AP_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__HOST:
				setHost(HOST_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__PORT:
				setPort(PORT_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__MODE:
				setMode(MODE_EDEFAULT);
				return;
			case IotwPackage.WIFI_ESP8266__ID_CONNECTION:
				setIdConnection(ID_CONNECTION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IotwPackage.WIFI_ESP8266__PIN_TX:
				return PIN_TX_EDEFAULT == null ? pinTX != null : !PIN_TX_EDEFAULT.equals(pinTX);
			case IotwPackage.WIFI_ESP8266__PIN_RX:
				return PIN_RX_EDEFAULT == null ? pinRX != null : !PIN_RX_EDEFAULT.equals(pinRX);
			case IotwPackage.WIFI_ESP8266__PIN_VCC:
				return PIN_VCC_EDEFAULT == null ? pinVcc != null : !PIN_VCC_EDEFAULT.equals(pinVcc);
			case IotwPackage.WIFI_ESP8266__PIN_GND:
				return PIN_GND_EDEFAULT == null ? pinGND != null : !PIN_GND_EDEFAULT.equals(pinGND);
			case IotwPackage.WIFI_ESP8266__PIN_CHPD:
				return PIN_CHPD_EDEFAULT == null ? pinCHPD != null : !PIN_CHPD_EDEFAULT.equals(pinCHPD);
			case IotwPackage.WIFI_ESP8266__SSID_ST:
				return SSID_ST_EDEFAULT == null ? sSID_ST != null : !SSID_ST_EDEFAULT.equals(sSID_ST);
			case IotwPackage.WIFI_ESP8266__PASSWORD_ST:
				return PASSWORD_ST_EDEFAULT == null ? password_ST != null : !PASSWORD_ST_EDEFAULT.equals(password_ST);
			case IotwPackage.WIFI_ESP8266__SSID_AP:
				return SSID_AP_EDEFAULT == null ? sSID_AP != null : !SSID_AP_EDEFAULT.equals(sSID_AP);
			case IotwPackage.WIFI_ESP8266__PASSWORD_AP:
				return PASSWORD_AP_EDEFAULT == null ? password_AP != null : !PASSWORD_AP_EDEFAULT.equals(password_AP);
			case IotwPackage.WIFI_ESP8266__HOST:
				return HOST_EDEFAULT == null ? host != null : !HOST_EDEFAULT.equals(host);
			case IotwPackage.WIFI_ESP8266__PORT:
				return port != PORT_EDEFAULT;
			case IotwPackage.WIFI_ESP8266__MODE:
				return mode != MODE_EDEFAULT;
			case IotwPackage.WIFI_ESP8266__ID_CONNECTION:
				return idConnection != ID_CONNECTION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (pinTX: ");
		result.append(pinTX);
		result.append(", pinRX: ");
		result.append(pinRX);
		result.append(", pinVcc: ");
		result.append(pinVcc);
		result.append(", pinGND: ");
		result.append(pinGND);
		result.append(", pinCHPD: ");
		result.append(pinCHPD);
		result.append(", sSID_ST: ");
		result.append(sSID_ST);
		result.append(", password_ST: ");
		result.append(password_ST);
		result.append(", sSID_AP: ");
		result.append(sSID_AP);
		result.append(", password_AP: ");
		result.append(password_AP);
		result.append(", host: ");
		result.append(host);
		result.append(", port: ");
		result.append(port);
		result.append(", mode: ");
		result.append(mode);
		result.append(", idConnection: ");
		result.append(idConnection);
		result.append(')');
		return result.toString();
	}
	@Override
	public EList<Pin> getPins() {
		EList<Pin> pins = new BasicEList<Pin>();
		pins.add(pinTX);
		pins.add(pinRX);
		pins.add(pinGND);
		pins.add(pinVcc);
		return pins;
	}
	@Override
	public void modifyPin(Pin pin) {
		if(pin.getName().equals(pinRX.getName())){
			setPinRX(pin);
		}
		else if(pin.getName().equals(pinTX.getName())){
			setPinTX(pin);
		}
		else if(pin.getName().equals(pinGND.getName())){
			setPinGND(pin);
		}
		else if(pin.getName().equals(pinVcc.getName())){
			setPinVcc(pin);
		}
	}
} //WifiESP8266Impl
