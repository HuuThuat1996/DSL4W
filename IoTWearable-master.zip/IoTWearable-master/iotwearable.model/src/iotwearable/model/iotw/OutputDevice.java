/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Device</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getOutputDevice()
 * @model abstract="true"
 * @generated
 */
public interface OutputDevice extends IODevice {
} // OutputDevice
