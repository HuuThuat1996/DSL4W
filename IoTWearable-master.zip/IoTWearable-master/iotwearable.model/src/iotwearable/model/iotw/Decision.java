/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getDecision()
 * @model
 * @generated
 */
public interface Decision extends StateComponent {
} // Decision
