/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Wifi ESP8266</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPinTX <em>Pin TX</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPinRX <em>Pin RX</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPinVcc <em>Pin Vcc</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPinGND <em>Pin GND</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPinCHPD <em>Pin CHPD</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getSSID_ST <em>SSID ST</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPassword_ST <em>Password ST</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getSSID_AP <em>SSID AP</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPassword_AP <em>Password AP</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getHost <em>Host</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getPort <em>Port</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getMode <em>Mode</em>}</li>
 *   <li>{@link iotwearable.model.iotw.WifiESP8266#getIdConnection <em>Id Connection</em>}</li>
 * </ul>
 * </p>
 *
 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266()
 * @model
 * @generated
 */
public interface WifiESP8266 extends Connectivity {
	/**
	 * Returns the value of the '<em><b>Pin TX</b></em>' attribute.
	 * The default value is <code>"TX,IO"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin TX</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin TX</em>' attribute.
	 * @see #setPinTX(Pin)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_PinTX()
	 * @model default="TX,IO" dataType="iotwearable.model.iotw.Pin"
	 * @generated
	 */
	Pin getPinTX();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPinTX <em>Pin TX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin TX</em>' attribute.
	 * @see #getPinTX()
	 * @generated
	 */
	void setPinTX(Pin value);

	/**
	 * Returns the value of the '<em><b>Pin RX</b></em>' attribute.
	 * The default value is <code>"RX,IO"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin RX</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin RX</em>' attribute.
	 * @see #setPinRX(Pin)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_PinRX()
	 * @model default="RX,IO" dataType="iotwearable.model.iotw.Pin"
	 * @generated
	 */
	Pin getPinRX();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPinRX <em>Pin RX</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin RX</em>' attribute.
	 * @see #getPinRX()
	 * @generated
	 */
	void setPinRX(Pin value);

	/**
	 * Returns the value of the '<em><b>Pin Vcc</b></em>' attribute.
	 * The default value is <code>"Vcc,Power"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin Vcc</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin Vcc</em>' attribute.
	 * @see #setPinVcc(Pin)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_PinVcc()
	 * @model default="Vcc,Power" dataType="iotwearable.model.iotw.Pin"
	 * @generated
	 */
	Pin getPinVcc();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPinVcc <em>Pin Vcc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin Vcc</em>' attribute.
	 * @see #getPinVcc()
	 * @generated
	 */
	void setPinVcc(Pin value);

	/**
	 * Returns the value of the '<em><b>Pin GND</b></em>' attribute.
	 * The default value is <code>"GND,Power"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin GND</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin GND</em>' attribute.
	 * @see #setPinGND(Pin)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_PinGND()
	 * @model default="GND,Power" dataType="iotwearable.model.iotw.Pin"
	 * @generated
	 */
	Pin getPinGND();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPinGND <em>Pin GND</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin GND</em>' attribute.
	 * @see #getPinGND()
	 * @generated
	 */
	void setPinGND(Pin value);

	/**
	 * Returns the value of the '<em><b>Pin CHPD</b></em>' attribute.
	 * The default value is <code>"CHPD,Power"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pin CHPD</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin CHPD</em>' attribute.
	 * @see #setPinCHPD(Pin)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_PinCHPD()
	 * @model default="CHPD,Power" dataType="iotwearable.model.iotw.Pin"
	 * @generated
	 */
	Pin getPinCHPD();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPinCHPD <em>Pin CHPD</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin CHPD</em>' attribute.
	 * @see #getPinCHPD()
	 * @generated
	 */
	void setPinCHPD(Pin value);

	/**
	 * Returns the value of the '<em><b>SSID ST</b></em>' attribute.
	 * The default value is <code>"IotWearable"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SSID ST</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SSID ST</em>' attribute.
	 * @see #setSSID_ST(String)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_SSID_ST()
	 * @model default="IotWearable"
	 * @generated
	 */
	String getSSID_ST();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getSSID_ST <em>SSID ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SSID ST</em>' attribute.
	 * @see #getSSID_ST()
	 * @generated
	 */
	void setSSID_ST(String value);

	/**
	 * Returns the value of the '<em><b>Password ST</b></em>' attribute.
	 * The default value is <code>"IotWearable"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Password ST</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Password ST</em>' attribute.
	 * @see #setPassword_ST(String)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_Password_ST()
	 * @model default="IotWearable"
	 * @generated
	 */
	String getPassword_ST();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPassword_ST <em>Password ST</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Password ST</em>' attribute.
	 * @see #getPassword_ST()
	 * @generated
	 */
	void setPassword_ST(String value);

	/**
	 * Returns the value of the '<em><b>SSID AP</b></em>' attribute.
	 * The default value is <code>"IotWearable"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SSID AP</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SSID AP</em>' attribute.
	 * @see #setSSID_AP(String)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_SSID_AP()
	 * @model default="IotWearable"
	 * @generated
	 */
	String getSSID_AP();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getSSID_AP <em>SSID AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SSID AP</em>' attribute.
	 * @see #getSSID_AP()
	 * @generated
	 */
	void setSSID_AP(String value);

	/**
	 * Returns the value of the '<em><b>Password AP</b></em>' attribute.
	 * The default value is <code>"IotWearable"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Password AP</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Password AP</em>' attribute.
	 * @see #setPassword_AP(String)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_Password_AP()
	 * @model default="IotWearable"
	 * @generated
	 */
	String getPassword_AP();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPassword_AP <em>Password AP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Password AP</em>' attribute.
	 * @see #getPassword_AP()
	 * @generated
	 */
	void setPassword_AP(String value);

	/**
	 * Returns the value of the '<em><b>Host</b></em>' attribute.
	 * The default value is <code>"192.168.200.46"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Host</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Host</em>' attribute.
	 * @see #setHost(String)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_Host()
	 * @model default="192.168.200.46"
	 * @generated
	 */
	String getHost();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getHost <em>Host</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Host</em>' attribute.
	 * @see #getHost()
	 * @generated
	 */
	void setHost(String value);

	/**
	 * Returns the value of the '<em><b>Port</b></em>' attribute.
	 * The default value is <code>"8080"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' attribute.
	 * @see #setPort(int)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_Port()
	 * @model default="8080"
	 * @generated
	 */
	int getPort();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getPort <em>Port</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Port</em>' attribute.
	 * @see #getPort()
	 * @generated
	 */
	void setPort(int value);

	/**
	 * Returns the value of the '<em><b>Mode</b></em>' attribute.
	 * The default value is <code>"Both"</code>.
	 * The literals are from the enumeration {@link iotwearable.model.iotw.WifiMode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode</em>' attribute.
	 * @see iotwearable.model.iotw.WifiMode
	 * @see #setMode(WifiMode)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_Mode()
	 * @model default="Both"
	 * @generated
	 */
	WifiMode getMode();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getMode <em>Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mode</em>' attribute.
	 * @see iotwearable.model.iotw.WifiMode
	 * @see #getMode()
	 * @generated
	 */
	void setMode(WifiMode value);

	/**
	 * Returns the value of the '<em><b>Id Connection</b></em>' attribute.
	 * The default value is <code>"id_0"</code>.
	 * The literals are from the enumeration {@link iotwearable.model.iotw.WifiIDConnection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id Connection</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Connection</em>' attribute.
	 * @see iotwearable.model.iotw.WifiIDConnection
	 * @see #setIdConnection(WifiIDConnection)
	 * @see iotwearable.model.iotw.IotwPackage#getWifiESP8266_IdConnection()
	 * @model default="id_0"
	 * @generated
	 */
	WifiIDConnection getIdConnection();

	/**
	 * Sets the value of the '{@link iotwearable.model.iotw.WifiESP8266#getIdConnection <em>Id Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Connection</em>' attribute.
	 * @see iotwearable.model.iotw.WifiIDConnection
	 * @see #getIdConnection()
	 * @generated
	 */
	void setIdConnection(WifiIDConnection value);

} // WifiESP8266
