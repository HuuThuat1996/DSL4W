/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Device</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getInputDevice()
 * @model abstract="true"
 * @generated
 */
public interface InputDevice extends IODevice {
} // InputDevice
