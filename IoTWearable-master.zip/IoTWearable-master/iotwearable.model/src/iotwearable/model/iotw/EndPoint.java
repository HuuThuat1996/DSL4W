/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>End Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getEndPoint()
 * @model
 * @generated
 */
public interface EndPoint extends StateComponent {
} // EndPoint
