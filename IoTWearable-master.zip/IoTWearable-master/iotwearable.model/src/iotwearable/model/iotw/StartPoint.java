/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Start Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getStartPoint()
 * @model
 * @generated
 */
public interface StartPoint extends StateComponent {
} // StartPoint
