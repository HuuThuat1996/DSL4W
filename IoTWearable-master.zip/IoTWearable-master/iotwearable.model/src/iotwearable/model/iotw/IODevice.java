/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IO Device</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getIODevice()
 * @model abstract="true"
 * @generated
 */
public interface IODevice extends Device {
} // IODevice
