/**
 */
package iotwearable.model.iotw;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connectivity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iotwearable.model.iotw.IotwPackage#getConnectivity()
 * @model abstract="true"
 * @generated
 */
public interface Connectivity extends Device {
} // Connectivity
